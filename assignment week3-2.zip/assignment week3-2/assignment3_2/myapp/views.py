from django.shortcuts import render, HttpResponse

# Create your views here.

import os

def index_handler(request):
    #得到目录中的全部文件名
    file_s = os.listdir(
        os.path.join('static','file')
    )
    return  render(request,'index.html', context = {'file_s': file_s})