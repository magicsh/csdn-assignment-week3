from django.db import models
import datetime

# Create your models here.

class User(models.Model):
    username = models.CharField(max_length=16, unique=True)
    password = models.CharField(max_length=32)
    age = models.SmallIntegerField()
    email = models.CharField(max_length=80)
    createDatetime = models.DateTimeField(auto_now_add=datetime.datetime.now())