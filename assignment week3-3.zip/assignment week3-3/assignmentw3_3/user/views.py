from django.shortcuts import render, HttpResponse
from user.models import User

# Create your views here.
def index_handler(request):
    #查找所有的user对象
    users = User.objects.all()
    #渲染模板，把users传递过去
    return render(request,'index.html',context={'users':users})

def add_handler(request):
    #如果是get请求，返回渲染好的新增用户界面
    if request.method=='GET':
        return render(request,'add.html')
    #如果是post请求，处理表单数据，写入数据库，返回操作结果
    else:
        # 得到用户名、年龄、密码、邮箱
        username = request.POST.get('username')
        password = request.POST.get('password')
        age = request.POST.get('age')
        email = request.POST.get('email')
        try:
            # 保存数据
            User(username=username,password=password,age=age,email=email).save()
            # 如果保存成功，返回操作结果页面，显示message
            return render(request,'result.html',{'message':'新增用户成功'})
        except:
            return render(request, 'result.html', {'message':'新增用户失败'})

def alter_handler(request,id):
    #得到被修改的对象
    user= User.objects.get(id=id)
    # 如果是get请求，渲染页面
    if request.method == 'GET':
        return render(request, 'alter.html', context={'user':user})
    # 如果是post请求，处理数据
    else:
        # 得到用户名、年龄、密码、邮箱
        username = request.POST.get('username')
        password = request.POST.get('password')
        age = request.POST.get('age')
        email = request.POST.get('email')
        #如果修改成功
        try:
            User.objects.get(id=id).save()
            return render(request, 'result.html', {'message': '修改用户成功'})
        #如果修改失败
        except:
            return render(request, 'result.html', {'message': '修改用户失败'})

def del_handler(request,id):
    #如果删除成功
    try:
        User.objects.get(id=id).delete()
        return render(request,'result.html',context={'message':'用户删除成功'})
    #如果删除失败
    except:
        return render(request,'result.html',context={'message':'用户删除失败'})